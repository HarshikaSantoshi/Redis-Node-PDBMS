// routes/shoppingCart.js
const express = require('express');
const router = express.Router();

const redis = require('redis');
const ObjectId = require('mongodb').ObjectId;
const { MongoClient } = require('mongodb');

const app = express();
app.use(express.json());

// Connection URI
const uri = 'mongodb://localhost:27017/pdbms';

// Create a new MongoClient
const client = new MongoClient(uri);

// Connect to MongoDB
client.connect()
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch(err => {
    console.error('Error connecting to MongoDB:', err);
  });



const redclient = redis.createClient();

// Add a product to the shopping cart
router.post('/:customerId/:productId', async (req, res) => {
  const { customerId, productId } = req.params;

  // Add product to Redis set
  redclient.sAdd(`cart:${customerId}`, productId, (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ customerId, productId });
      res.render('shoppingcart');
    }
  });

  // You can also update MongoDB data if needed
  const db = getMongoDB();
  try {
    const result = await db.collection('customer').findOneAndUpdate(
      { _id: new ObjectId(customerId) },
      { $addToSet: { cart: productId } },
      { returnDocument: 'after' }
    );
    console.log(`MongoDB: Updated shopping cart for customer ${customerId}`, result.value);
  } catch (error) {
    console.error(`MongoDB: Error updating shopping cart for customer ${customerId}`, error);
  }
});

// Remove a product from the shopping cart
router.delete('/:customerId/:productId', async (req, res) => {
    const { customerId, productId } = req.params;
  
    // Remove product from Redis set
    redclient.sRem(`cart:${customerId}`, productId, (err, result) => {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        res.json({ customerId, productId, removed: result > 0 });
      }
    });
  
    // You can also update MongoDB data if needed
    const db = getMongoDB();
    try {
      const result = await db.collection('customer').findOneAndUpdate(
        { _id: new ObjectId(customerId) },
        { $pull: { cart: productId } },
        { returnDocument: 'after' }
      );
      console.log(`MongoDB: Updated shopping cart for customer ${customerId}`, result.value);
    } catch (error) {
      console.error(`MongoDB: Error updating shopping cart for customer ${customerId}`, error);
    }
  });

  
// Get shopping cart for a customer
router.get('/:customerId', (req, res) => {
  const { customerId } = req.params;

  // Get product IDs from Redis set
  redclient.sMembers(`cart:${customerId}`, (err, products) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ customerId, products });
      res.render('shoppingcart'); 
    }
  });
});

module.exports = router;

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

