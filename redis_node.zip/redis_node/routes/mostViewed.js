const express = require('express');
const redis = require('redis');
const { MongoClient } = require('mongodb');
const { promisify } = require('util');

const app = express();
app.use(express.json());

const REDIS_PORT = 6379;
const MONGO_URL = 'mongodb://localhost:27017/pdbms';

// Create Redis client
const redisClient = redis.createClient(REDIS_PORT);

// Promisify Redis functions for async/await
const zAddAsync = promisify(redisClient.zAdd).bind(redisClient);
const zIncrByAsync = promisify(redisClient.zIncrBy).bind(redisClient);
const zRangeAsync = promisify(redisClient.zRange).bind(redisClient);
const zRemAsync = promisify(redisClient.zRem).bind(redisClient);

// Connect to MongoDB
const mongoClient = new MongoClient(MONGO_URL);

app.post('/views/:productId', async (req, res) => {
  const { productId } = req.params;

  try {
    // Increment views in Redis sorted set
    await zIncrByAsync('mostViewed', 1, productId);

    // Increment views in MongoDB
    await updateMongoDBViews(productId);
    res.render('mostviewed', { productId, views: views || 0 });

    res.status(200).json({ success: true, message: 'Views incremented successfully.' });
  } catch (error) {
    console.error('Error incrementing views:', error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});

app.get('/views/:productId', async (req, res) => {
  const { productId } = req.params;

  try {
    // Retrieve views from Redis sorted set
    const views = await zRangeAsync('mostViewed', 0, -1, 'WITHSCORES');
    res.render('mostviewed', { productId, views: views || 0 });

    res.status(200).json({ success: true, views });
  } catch (error) {
    console.error('Error retrieving views:', error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});

app.delete('/views/:productId', async (req, res) => {
  const { productId } = req.params;

  try {
    // Remove product from Redis sorted set
    await zRemAsync('mostViewed', productId);

    res.status(200).json({ success: true, message: 'Product removed from mostViewed.' });
  } catch (error) {
    console.error('Error removing product from mostViewed:', error);
    res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});

// Update views in MongoDB (simulated)
async function updateMongoDBViews(productId) {
  await mongoClient.connect();
  const db = mongoClient.db('pdbms');
  const productsCollection = db.collection('product');

  await productsCollection.updateOne(
    { productId: parseInt(productId) },
    { $inc: { views: 1 } }
  );

  await mongoClient.close();
}


const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});